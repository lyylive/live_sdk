//
//  AppDelegate.h
//  LYYLiveSDKDemo
//
//  Created by Jobs on 2017/11/2.
//  Copyright © 2017年 Jobs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

