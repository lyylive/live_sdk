//
//  LYYLiveManager.h
//  LYYLiveSDK
//
//  Created by Jobs on 2017/10/29.
//  Copyright © 2017年 Jobs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^LYYSuccessBlock)();
typedef void (^LYYFailureBlock)(NSString *module, int errId, NSString *errMsg);

@interface LYYLiveManager : NSObject

/**
 *  获取单例
 *
 *  @return 单例对象
 */
+ (instancetype)sharedManager;

/**
 *  初始化SDK
 *
 *  @param appId       AppId
 *  @param accountType 账号类型
 */
- (void)initSdk:(int)appId accountType:(int)accountType;

/**
 *  登录
 *
 *  @param userId  用户id
 *  @param sig     sig
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)loginWithUserId:(NSString *)userId sig:(NSString *)sig success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  加入房间
 *
 *  @param roomId   房间id
 *  @param masterId 主播id
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)joinRoomWithRoomId:(int)roomId masterId:(NSString *)masterId success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  切换房间
 *
 *  @param roomId   房间id
 *  @param masterId 主播id
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)switchRoomWithRoomId:(int)roomId masterId:(NSString *)masterId success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  退出房间
 *
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)quitRoomSuccess:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  上麦
 *
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)upToVideoMemberSuccess:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  下麦
 *
 *  @param success 成功回调
 *  @param failure 失败回调
 */
- (void)downToVideoMemberSuccess:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

/**
 *  播放视频
 *
 *  @param view 视频所在视图
 */
- (void)playingInView:(UIView *)view;

/**
 *  停止播放视频
 */
- (void)stopPlaying;

@end
