//
//  ViewController.m
//  LYYLiveSDKDemo
//
//  Created by Jobs on 2017/11/2.
//  Copyright © 2017年 Jobs. All rights reserved.
//

#import "ViewController.h"
#import <LYYLiveSDK/LYYLiveManager.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    __weak typeof(self) weakSelf = self;
    
    //加入房间
    int roomId = 10000;
    NSString *masterId = @"888";
    [[LYYLiveManager sharedManager] joinRoomWithRoomId:roomId masterId:masterId success:^{
        
        //播放视频
        [[LYYLiveManager sharedManager] playingInView:weakSelf.view];
        
        //请求上麦
        [[LYYLiveManager sharedManager] upToVideoMemberSuccess:nil failure:nil];
        
    } failure:^(NSString *module, int errId, NSString *errMsg) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"加入房间失败" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
    }];
}

- (void)dealloc {
    
    //下麦
    [[LYYLiveManager sharedManager] downToVideoMemberSuccess:nil failure:nil];
    
    //停止播放视频
    [[LYYLiveManager sharedManager] stopPlaying];
    
    //退出房间
    [[LYYLiveManager sharedManager] quitRoomSuccess:nil failure:nil];
}

@end
