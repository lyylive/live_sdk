//
//  LYYLiveManager.h
//  LYYLiveSDK
//
//  Created by Jobs on 2017/10/29.
//  Copyright © 2017年 Jobs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^LYYSuccessBlock)();
typedef void (^LYYFailureBlock)(NSString *module, int errId, NSString *errMsg);

@interface LYYLiveManager : NSObject

@property (nonatomic, strong) NSString *masterId;   //主播标识

+ (instancetype)sharedManager;

//初始化SDK
- (int)initSdk:(int)appId accountType:(int)accountType;

//登录
- (void)loginWithUserId:(NSString *)userId sig:(NSString *)sig success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

//加入房间
- (void)joinRoomWithRoomId:(int)roomId success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

//退出房间
- (void)quitRoomSuccess:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

//上麦
- (void)upToVideoMemberWithMasterId:(NSString *)masterId success:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

//下麦
- (void)downToVideoMemberSuccess:(LYYSuccessBlock)success failure:(LYYFailureBlock)failure;

//播放视频
- (void)playingInView:(UIView *)view;

//停止播放视频
- (void)stopPlaying;

@end
