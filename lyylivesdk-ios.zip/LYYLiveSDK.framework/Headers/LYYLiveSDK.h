//
//  LYYLiveSDK.h
//  LYYLiveSDK
//
//  Created by Jobs on 2017/10/29.
//  Copyright © 2017年 Jobs. All rights reserved.
//

#import <LYYLiveSDK/LYYLiveManager.h>

